package com.view;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.annotation.HibernateConfig;
import com.model.Customer;
import com.service.CustomerService;

public class HibernateMain {
	public static void main(String args[]) {

		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(HibernateConfig.class);
		CustomerService customerService = (CustomerService) context.getBean(CustomerService.class);
		//Customer customer = new Customer("Minu", "minu@gmail.com");
		//customerService.addCustomer(customer);
		List<Customer> customerList = customerService.getAllCustomers();
		System.out.println(customerList.size());
		for (Customer record : customerList) {
			System.out.print("ID : " + record.getId());
			System.out.print(", Name : " + record.getCustomerName());
			System.out.println(", Email : " + record.getEmail());
		}
	/*	Customer cust=new Customer();
		cust.setId(4);
		cust.setCustomerName("Kavi");
		cust.setEmail("kavi@gmail.com");
		customerService.updateCustomer(cust);
		
		System.out.println("After updating ");
		Customer c=customerService.getCustomer(4);
		System.out.println(c);*/
		
		customerService.deleteCustomer(4);
		
		System.out.println("After deleting ");
		customerList = customerService.getAllCustomers();
		for (Customer record : customerList) {
			System.out.print("ID : " + record.getId());
			System.out.print(", Name : " + record.getCustomerName());
			System.out.println(", Email : " + record.getEmail());
		}
	}
}
