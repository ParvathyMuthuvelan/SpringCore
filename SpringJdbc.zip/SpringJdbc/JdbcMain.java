//MVC -model,view,controller

//request->(dispatcherservlet)controller->service(bo -business object)->dao(data access object)

//main->service-dao

package com.view;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.model.Person;
import com.service.PersonServiceImpl;

public class JdbcMain {

	public static void main(String[] args) {
		/*
		 * AnnotationConfigApplicationContext context = new
		 * AnnotationConfigApplicationContext( HibernateConfig.class); CustomerService
		 * customerService = (CustomerService) context.getBean(CustomerService.class);
		 * Customer customer=new Customer("Sri", "sri@gmail.com");
		 * customerService.addCustomer(customer); List<Customer>
		 * customerList=customerService.getAllCustomers();
		 * System.out.println(customerList.size()); for (Customer record : customerList)
		 * { System.out.print("ID : " + record.getId()); System.out.print(", Name : " +
		 * record.getCustomerName()); System.out.println(", Email : " +
		 * record.getEmail()); }
		 */
//		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(
//				SpringJdbcConfig.class);	
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		PersonServiceImpl personService = (PersonServiceImpl) context.getBean("personService");
		System.out.println("------Records Creation--------");

		personService.create("Kavi", 31);

		System.out.println("------Listing All Persons--------");

		List<Person> list = personService.listPersons();
		for (Person record : list) {
			System.out.print("ID : " + record.getId());
			System.out.print(", Name : " + record.getName());
			System.out.println(", Age : " + record.getAge());
		}
		System.out.println("----Updating Record with ID = 2 -----");
		personService.update(2, 45);

		System.out.println("----Listing Record with ID = 2 -----");
		Person person = personService.getPerson(2);
		System.out.print("ID : " + person.getId());
		System.out.print(", Name : " + person.getName());
		System.out.println(", Age : " + person.getAge());

		System.out.println("----Deleting Record with ID = 5 -----");
		personService.delete(10);

		System.out.println("------Listing All Persons after deleting record with ID 5--------");

		list = personService.listPersons();
		for (Person record : list) {
			System.out.print("ID : " + record.getId());
			System.out.print(", Name : " + record.getName());
			System.out.println(", Age : " + record.getAge());
		}
	}
}
