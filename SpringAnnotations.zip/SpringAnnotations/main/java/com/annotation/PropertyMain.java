package com.annotation;

import java.util.Arrays;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PropertyMain {

	public static void main(String[] args) {
	ApplicationContext context = new 
AnnotationConfigApplicationContext(BeanConfig.class);
	PopulateBean bean=context.getBean(PopulateBean.class);
	//	System.out.println(Arrays.toString(bean.getValuesArray()));
	
		System.out.println(bean.getValuesList());
		System.out.println(bean.getValuesMap());
		System.out.println(bean.getValuesMapKey1());
	

	}

}
