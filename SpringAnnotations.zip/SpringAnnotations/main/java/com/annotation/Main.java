package com.annotation;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
//Java Based Configuration
public class Main {
	public static void main(String[] args) {
		
		ApplicationContext context = new 
				AnnotationConfigApplicationContext(BeanConfig.class);
		//HelloWorld obj = (HelloWorld)context.getBean("helloBean");
		HelloWorld obj = context.getBean(HelloWorld.class);
		obj.setMessage("Hello World!");
		System.out.println(obj.getMessage());
		Employee e=(Employee)context.getBean(Employee.class);
		e.setId(1001);
		e.setName("sri");
		System.out.println(e);
		//System.out.println(e.getDepartment().getManager());

//		ApplicationContext context = new 
//				AnnotationConfigApplicationContext(BeanConfig.class, DBconfig.class); 
//	         DBconfig config = context.getBean(DBconfig.class);
//	      System.out.println(config);
		Shop shop=context.getBean(Shop.class);
		//System.out.println(shop.getProductDetails());
		shop.displayProduct();
		
	}
}
