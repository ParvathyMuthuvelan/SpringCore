package com.annotation;

import java.util.Map;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Value;

public class Shop {

	
	private String shopName;
	private String shopLocation;
	@Value("#{{'I01': 100, 'I02': 250, 'I03': 340}}")
	//@Value("#{db}")
	private Map<String,Integer> productDetails;

	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getShopLocation() {
		return shopLocation;
	}
	public void setShopLocation(String shopLocation) {
		this.shopLocation = shopLocation;
	}
	public Map<String, Integer> getProductDetails() {
		return productDetails;
	}
	//@Value("#{{'KEY1': 10, 'KEY2': 20, 'KEY3': 30}}")
	public void setProductDetails(Map<String, Integer> productDetails) {
		this.productDetails = productDetails;
		
	}	
	void displayProduct()
	{
		for(Entry<String, Integer> entry:productDetails.entrySet())
		{
			System.out.println(entry.getKey() +" "+entry.getValue());
		}
	}
}














