package com.annotation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;



@Configuration
@PropertySource({"classpath:data.properties","classpath:db.properties"})
public class BeanConfig {
	@Autowired
	  Department dept;
   @Bean 
   //@Scope("prototype")
   public HelloWorld helloWorld(){
      return new HelloWorld();
   }
   
   @Bean 
   public DBconfig getDBConfig(){
      return new DBconfig();
   }
   
   @Bean 
   public Person getPerson(){
      return new Person();
   }
   @Bean 
   public Department getDepartment(){
	 dept=new Department("IT","ABC");
	  // dept.setDepartmentName("IT");
	 //  dept.setManager("ABC");
      return dept;
   }
   @Bean (name="emp")
   public Employee getEmployee(){
	   //return new Employee();
      return new Employee(1001,"Sri",dept);
   }
   

//   @Bean
//   public PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
//       PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
//       propertySourcesPlaceholderConfigurer.setLocations(new ClassPathResource("data.properties"));
//       return propertySourcesPlaceholderConfigurer;
//   }
     
   @Bean 
   public Shop getShop(){
	   Shop shop=new Shop();
	  
      return shop;
   }
   @Bean
   public PopulateBean getPropBean()
   {
	   PopulateBean bean=new PopulateBean();
	   return bean;
   }
//   @Bean
//   public CollectionProvider getCollectionBean()
//   {
//	   CollectionProvider bean=new CollectionProvider();
//	   return bean;
//   }
}
