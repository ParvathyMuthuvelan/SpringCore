package com.annotation;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
public class PopulateBean {
	@Value("${listOfValues}")
	//private String[] valuesArray;
	private List<String> valuesList;
	
//	@Value("#{'${listOfValues}'.split(',')}")
//	private List<String> valuesList;
	
	@Value("#{${valuesMap}}")
	private Map<String, Integer> valuesMap;
	
	@Value("#{${valuesMap}.key3}")
	private Integer valuesMapKey1;
	
	
	

//	public String[] getValuesArray() {
//		return valuesArray;
//		
//	}



	public Integer getValuesMapKey1() {
		return valuesMapKey1;
	}

	public void setValuesMapKey1(Integer valuesMapKey1) {
		this.valuesMapKey1 = valuesMapKey1;
	}

	public List<String> getValuesList() {
		return valuesList;
	}

	public void setValuesList(List<String> valuesList) {
		this.valuesList = valuesList;
	}

	public Map<String, Integer> getValuesMap() {
		return valuesMap;
	}

	

	
}
