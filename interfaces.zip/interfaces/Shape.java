package com.interfaces;

public interface Shape {
double calculateArea();
}
