	<!-- Bean Inheritancce -->
	<bean id="baseCustomer" class="com.inheritance.Customer"
		abstract="true">
		<property name="country" value="India" />
	</bean>

	<bean id="customer" parent="baseCustomer">
		<!-- <property name="country" value="USA" /> -->
		<property name="name" value="kb" />
		<property name="email" value="kb@gmail.com" />
	</bean>