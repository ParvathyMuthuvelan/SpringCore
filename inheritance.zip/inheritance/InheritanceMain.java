package com.inheritance;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class InheritanceMain {

	public static void main(String[] args) {
		ApplicationContext context = 
				new ClassPathXmlApplicationContext("Beans.xml");

		 Customer baseCustomer = (Customer)
		 context.getBean("baseCustomer");
		 System.out.println(baseCustomer);

		Customer customer = (Customer) context.getBean("customer");
		System.out.println(customer);
	}
}
